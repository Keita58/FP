package Examen.utils;

public class TextPantalla {
    private String estat;

    public TextPantalla() {
        super();
    }

    public TextPantalla(String estat) {
        super();
        this.estat = estat;
    }

    public String getEstat() {
        return estat;
    }

    public void setEstat(String estat) {
        this.estat = estat;
    }

}

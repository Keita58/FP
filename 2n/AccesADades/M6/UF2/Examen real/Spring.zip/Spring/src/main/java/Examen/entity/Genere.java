package Examen.entity;

public enum Genere {
    FEMENI,
    MASCULI,
    ALTRES
}

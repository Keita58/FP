package DAO;

import entity.Personatges;

import java.io.Serializable;

public interface IPersonatgeDAO extends IGenericDAO<Personatges, Integer>, Serializable {
}

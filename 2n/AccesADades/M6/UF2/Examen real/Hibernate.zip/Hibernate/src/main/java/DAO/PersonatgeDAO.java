package DAO;

import entity.Personatges;

public class PersonatgeDAO extends GenericDAO<Personatges, Integer> implements IPersonatgeDAO{

}

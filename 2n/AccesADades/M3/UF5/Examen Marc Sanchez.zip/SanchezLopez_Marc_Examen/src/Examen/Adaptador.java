package Examen;

public interface Adaptador {

	double getPreu();
}

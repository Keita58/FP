package Examen;

public enum Sabors {

	LLIMONA,
	XOCOLATA,
	MENTA,
	VAINILLA,
	MADUIXA
}

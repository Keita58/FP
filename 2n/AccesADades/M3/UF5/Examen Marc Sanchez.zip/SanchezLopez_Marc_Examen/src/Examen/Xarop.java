package Examen;

public interface Xarop {

	String getNom();
	double getPreu();
	void setPreu(double d);
}

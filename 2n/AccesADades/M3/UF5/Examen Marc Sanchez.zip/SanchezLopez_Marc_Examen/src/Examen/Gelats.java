package Examen;

public interface Gelats {

	String getNom();
	String getDescripcio();
	double getPreu();
	void setPreu(double d);
	boolean getIncrement();
	Gelats getGelat();
}

/**
 * 
 */
/**
 * 
 */
module SanchezLopez_Marc_Examen {
	requires java.desktop;
    requires java.sql;
    requires java.base;
    requires mysql.connector.java;
}
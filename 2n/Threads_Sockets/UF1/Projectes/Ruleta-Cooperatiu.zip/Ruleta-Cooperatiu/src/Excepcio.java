public class Excepcio extends Exception{

    public Excepcio(String s) {
        super(s);
    }
}

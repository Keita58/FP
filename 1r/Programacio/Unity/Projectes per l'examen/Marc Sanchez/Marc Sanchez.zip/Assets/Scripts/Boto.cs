using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boto : MonoBehaviour
{
    public void click()
    {
        print("Has guanyat!!");
    }
}
